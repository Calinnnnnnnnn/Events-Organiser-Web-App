package com.events_organiser.manage_events.controller;

import com.events_organiser.manage_events.model.User;
import com.events_organiser.manage_events.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringJUnitConfig(ProfileControllerTest.Config.class) // Folosim o configurație personalizată
@WebMvcTest(ProfileController.class)
public class ProfileControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserService userService; // Injectăm mock-ul definit în Config

    @BeforeEach
    public void setup() {
        Mockito.reset(userService); // Resetăm mock-ul înainte de fiecare test
    }

    @Test
    public void testShowProfile() throws Exception {
        User mockUser = new User();
        mockUser.setId_user(1);
        mockUser.setFirstName("John");
        mockUser.setLastName("Doe");
        mockUser.setUsername("johndoe");
        mockUser.setEmail("john.doe@example.com");

        when(userService.findUserById(1)).thenReturn(mockUser);

        mockMvc.perform(get("/profile").sessionAttr("loggedUserId", 1))
                .andExpect(status().isOk())
                .andExpect(view().name("profile"))
                .andExpect(model().attribute("user", mockUser));
    }

    @Configuration
    @Import(ProfileController.class) // Importăm controller-ul în configurația de test
    static class Config {
        @Bean
        public UserService userService() {
            return Mockito.mock(UserService.class); // Definim manual mock-ul
        }
    }
}