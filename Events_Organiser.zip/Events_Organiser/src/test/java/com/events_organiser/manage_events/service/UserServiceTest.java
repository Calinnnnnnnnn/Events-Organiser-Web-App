package com.events_organiser.manage_events.service;

import com.events_organiser.manage_events.model.User;
import com.events_organiser.manage_events.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private BCryptPasswordEncoder passwordEncoder;

    @InjectMocks
    private UserService userService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this); // Inițializează obiectele mock
    }

    @Test
    public void testSaveUser() {
        // Datele de intrare
        User user = new User();
        user.setUsername("johndoe");
        user.setPassword("Password1!");

        // Mock pentru criptarea parolei
        when(passwordEncoder.encode("Password1!")).thenReturn("$2a$10$encodedPassword");

        // Mock pentru salvarea utilizatorului
        when(userRepository.save(user)).thenReturn(user);

        // Apelează metoda de testat
        User savedUser = userService.saveUser(user);

        // Verificări
        assertNotNull(savedUser);
        assertEquals("johndoe", savedUser.getUsername());
        assertEquals("$2a$10$encodedPassword", savedUser.getPassword());

        // Verificăm că metodele repository-ului și encoder-ului au fost apelate
        verify(passwordEncoder, times(1)).encode("Password1!");
        verify(userRepository, times(1)).save(user);
    }

    @Test
    public void testFindUserById() {
        // Datele de intrare
        User user = new User();
        user.setId_user(1);
        user.setUsername("johndoe");

        // Mock pentru găsirea utilizatorului
        when(userRepository.findById(1)).thenReturn(Optional.of(user));

        // Apelează metoda de testat
        User foundUser = userService.findUserById(1);

        // Verificări
        assertNotNull(foundUser);
        assertEquals(1, foundUser.getId_user());
        assertEquals("johndoe", foundUser.getUsername());

        // Verificăm că repository-ul a fost apelat
        verify(userRepository, times(1)).findById(1);
    }

    @Test
    public void testAuthenticateUser_ValidCredentials() {
        // Datele de intrare
        User user = new User();
        user.setUsername("johndoe");
        user.setPassword("$2a$10$encodedPassword");

        // Mock pentru găsirea utilizatorului
        when(userRepository.findByUsername("johndoe")).thenReturn(Optional.of(user));

        // Mock pentru validarea parolei
        when(passwordEncoder.matches("Password1!", "$2a$10$encodedPassword")).thenReturn(true);

        // Apelează metoda de testat
        boolean isAuthenticated = userService.authenticateUser("johndoe", "Password1!");

        // Verificări
        assertTrue(isAuthenticated);

        // Verificăm că repository-ul și encoder-ul au fost apelate
        verify(userRepository, times(1)).findByUsername("johndoe");
        verify(passwordEncoder, times(1)).matches("Password1!", "$2a$10$encodedPassword");
    }

    @Test
    public void testAuthenticateUser_InvalidCredentials() {
        // Datele de intrare
        User user = new User();
        user.setUsername("johndoe");
        user.setPassword("$2a$10$encodedPassword");

        // Mock pentru găsirea utilizatorului
        when(userRepository.findByUsername("johndoe")).thenReturn(Optional.of(user));

        // Mock pentru validarea parolei
        when(passwordEncoder.matches("WrongPassword!", "$2a$10$encodedPassword")).thenReturn(false);

        // Apelează metoda de testat
        boolean isAuthenticated = userService.authenticateUser("johndoe", "WrongPassword!");

        // Verificări
        assertFalse(isAuthenticated);

        // Verificăm că repository-ul și encoder-ul au fost apelate
        verify(userRepository, times(1)).findByUsername("johndoe");
        verify(passwordEncoder, times(1)).matches("WrongPassword!", "$2a$10$encodedPassword");
    }
}