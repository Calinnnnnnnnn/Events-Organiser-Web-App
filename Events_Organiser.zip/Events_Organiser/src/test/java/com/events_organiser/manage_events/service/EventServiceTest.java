package com.events_organiser.manage_events.service;

import com.events_organiser.manage_events.model.Event;
import com.events_organiser.manage_events.repository.EventRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EventServiceTest {

    @Mock
    private EventRepository eventRepository;

    @InjectMocks
    private EventService eventService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetEventByUserId(){
        Integer userId = 1;
        List<Event> events = new ArrayList<>();
        Event event1 = new Event();
        event1.setIdEvent(1);
        event1.setEventName("Event 1");
        events.add(event1);

        when(eventRepository.findByUserId(userId)).thenReturn(events);

        List<Event> result = eventService.getEventByUserId(userId);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Event 1", result.get(0).getEventName());
        verify(eventRepository, times(1)).findByUserId(userId);
    }

    @Test
    void testSaveEvent() {
        Event event = new Event();
        event.setIdEvent(1);
        event.setEventName("New Event");
        when(eventRepository.save(event)).thenReturn(event);
        eventService.saveEvent(event);
        verify(eventRepository, times(1)).save(event);
    }

    @Test
    void testFindNextEvent() {
        Integer userId = 1;
        Event nextEvent = new Event();
        nextEvent.setIdEvent(2);
        nextEvent.setEventName("Next Event");
        nextEvent.setEventDate(LocalDateTime.now().plusDays(1));

        when(eventRepository.findTopByUserIdAndEventDateAfterOrderByEventDateAsc(eq(userId), any(LocalDateTime.class)))
                .thenReturn(nextEvent);

        Event result = eventService.findNextEvent(userId);

        assertNotNull(result);
        assertEquals("Next Event", result.getEventName());
        verify(eventRepository, times(1))
                .findTopByUserIdAndEventDateAfterOrderByEventDateAsc(eq(userId), any(LocalDateTime.class));
    }

    @Test
    void testGetEventById() {
        Integer eventId = 1;
        Event event = new Event();
        event.setIdEvent(eventId);
        event.setEventName("Test Event");

        when(eventRepository.findById(eventId)).thenReturn(Optional.of(event));

        Event result = eventService.getEventById(eventId);

        assertNotNull(result);
        assertEquals("Test Event", result.getEventName());
        verify(eventRepository, times(1)).findById(eventId);
    }
}
