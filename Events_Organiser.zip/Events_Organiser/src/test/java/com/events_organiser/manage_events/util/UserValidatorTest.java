package com.events_organiser.manage_events.util;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class UserValidatorTest {

    @Test
    public void testValidateUserWithValidData(){
        List<String> errors = UserValidator.validateUser(
                "TestNume",
                "TestPrenume",
                "username_test",
                "nume.prenume@gmail.com",
                "Password1!",
                "Password1!"
        );
        assertTrue(errors.isEmpty());
    }

    @Test
    public void testValidateUserWithInvalidEmail(){
        List<String> errors = UserValidator.validateUser(
                "TestNume",
                "TestPrenume",
                "username_test",
                "invalid-email",
                "Password1!",
                "Password1!"
        );
        assertFalse(errors.isEmpty());
        assertTrue(errors.contains("Invalid email format."));
    }

    @Test
    public void testValidateUserWithInvalidPassword(){
        List<String> errors = UserValidator.validateUser(
                "TestNume",
                "TestPrenume",
                "username_test",
                "nume.prenume@gmail.com",
                "password1",
                "password1"
        );
        assertFalse(errors.isEmpty());
        assertTrue(errors.contains("Invalid password format."));
    }

    @Test
    public void testValidateUserWithPasswordMismatch(){
        List<String> errors = UserValidator.validateUser(
                "TestNume",
                "TestPrenume",
                "username_test",
                "invalid-email",
                "Password1!",
                "Password2!"
        );
        assertFalse(errors.isEmpty());
        assertTrue(errors.contains("Passwords do not match."));
    }
}
