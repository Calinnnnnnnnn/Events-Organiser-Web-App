package com.events_organiser.manage_events.service;

import com.events_organiser.manage_events.model.Event;
import com.events_organiser.manage_events.model.EventExtras;
import com.events_organiser.manage_events.repository.EventRepository;
import com.events_organiser.manage_events.repository.EventExtrasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class EventService {

    // repo-urile pentru gestionarea datelor evenimentelor si optiunilor suplimentare
    @Autowired
    private final EventRepository eventRepository;
    private final EventExtrasRepository eventExtrasRepository;

    // constructorul clasei pentru injectarea dependentelor
    public EventService(EventRepository eventRepository, EventExtrasRepository eventExtrasRepository) {
        this.eventRepository = eventRepository;
        this.eventExtrasRepository = eventExtrasRepository;
    }

    // gasirea evenimentelor unui user utilizand id-ul acestuia
    public List<Event> getEventByUserId(Integer userId) {
        return eventRepository.findByUserId(userId);
    }

    // gasirea urmatorului eveniment utilizand id-ul userului
    public Event findNextEvent(Integer userId) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        return eventRepository.findTopByUserIdAndEventDateAfterOrderByEventDateAsc(userId, currentDateTime);
    }

    // salvarea unui eveniment
    public void saveEvent(Event event) {
        if(event.getCreatedAt() == null) {
            event.setCreatedAt(LocalDateTime.now());
        }
        eventRepository.save(event);
    }

    // salvarea extraoptiunilor pentru un eveniment
    public void saveEventExtras(EventExtras eventExtras) {
        eventExtrasRepository.save(eventExtras);
    }

    //extragerea unui eveniment pe baza id-ului acestuia
    public Event getEventById(Integer eventId) {
        return eventRepository.findById(eventId).get();
    }
}
