package com.events_organiser.manage_events.controller;

import com.events_organiser.manage_events.model.User;
import com.events_organiser.manage_events.service.UserService;
import com.events_organiser.manage_events.util.UserValidator;
import jakarta.servlet.http.HttpSession;
import org.hibernate.id.IntegralDataTypeHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ProfileController {

    @Autowired
    private UserService userService;

    //afisrea paginii de profil pentru un utilizator logat
    @GetMapping("/profile")
    public String showProfile(Model model, HttpSession session) {
        Integer userId = (Integer) session.getAttribute("loggedUserId");
        //verificare daca utilizatorul este logat
        if(userId == null) {
            return "redirect:/login";
        }
        User user = userService.findUserById(userId);
        if(user == null) {
            return "redirect:/dashboard";
        }

        model.addAttribute("user", user);

        return "profile";
    }

    //update pentru datele unui utilizator
    @PostMapping("/profile/update")
    public String updateProfile(@ModelAttribute User user,
                                @ModelAttribute("confirmPassword") String confirmPassword,
                                HttpSession session,
                                Model model) {
        Integer userId = (Integer) session.getAttribute("loggedUserId");

        //verificare daca utilizatorul este logat
        if (userId == null) {
            return "redirect:/login";
        }

        //preluarea datelor despre utilizator pentru a precompleta campurile
        // din pagina cu ele
        List<String> errors = UserValidator.validateUserUpdate(
                user.getFirstName(),
                user.getLastName(),
                user.getUsername(),
                user.getEmail(),
                user.getPassword(),
                confirmPassword,
                userService,
                userId
        );

        if (!errors.isEmpty()) {
            model.addAttribute("errors", errors);
            model.addAttribute("user", user); // Păstrăm datele completate
            return "profile";
        }

        user.setId_user(userId);
        if (user.getPassword() != null && !user.getPassword().isBlank()) {
            user.setPassword(userService.encodePassword(user.getPassword()));
        } else {
            // Preia parola existentă din baza de date pentru a nu o modifica
            User existingUser = userService.findUserById(userId);
            user.setPassword(existingUser.getPassword());
        }
        //folosirea metodei de update definita in UserService
        userService.updateUser(user);

        //daca utilizatorul isi schimba username-ul acesta trebuie schimbat
        // si in sesiune
        session.setAttribute("authenticatedUser", user.getUsername());

        //mesaj de succes
        model.addAttribute("successMessage", "Profile updated successfully!");
        return "redirect:/dashboard";
    }
}
