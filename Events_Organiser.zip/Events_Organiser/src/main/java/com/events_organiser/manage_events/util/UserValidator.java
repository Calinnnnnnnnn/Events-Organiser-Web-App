package com.events_organiser.manage_events.util;

import com.events_organiser.manage_events.model.User;
import com.events_organiser.manage_events.service.UserService;

import java.util.ArrayList;
import java.util.List;

public class UserValidator {
    public static List<String> validateUser(String firstName, String lastName, String username, String email, String password, String confirmPassword) {
        List<String> errors = new ArrayList<>();

        //verificare firstName
        if(firstName == null || firstName.isEmpty()){
            errors.add("First name is required.");
        }

        if(lastName == null || lastName.isEmpty()){
            errors.add("Last name is required.");
        }

        // verificare username
        if (username == null || username.isEmpty()) {
            errors.add("Username is required.");
        }

        // verificare email
        if (email == null || email.isBlank()) {
            errors.add("Email is required.");
        } else if (!email.matches("^[a-zA-Z0-9](?!.*\\.\\.)[a-zA-Z0-9._-]*[a-zA-Z0-9]@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,6}$")) {
            errors.add("Invalid email format.");
        }


        // verificare parola
        if (password == null || password.isBlank()) {
            errors.add("Password is required.");
        } else {
            if (password.length() < 8) {
                errors.add("Password must be at least 8 characters long.");
            }
            if (!password.matches(".*[a-z].*")) {
                errors.add("Password must contain at least one lowercase letter.");
            }
            if (!password.matches(".*[A-Z].*")) {
                errors.add("Password must contain at least one uppercase letter.");
            }
            if (!password.matches(".*\\d.*")) {
                errors.add("Password must contain at least one number.");
            }
            if (!password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
                errors.add("Password must contain at least one special character.");
            }
        }

        // verificare confirmare parola
        if (confirmPassword == null || confirmPassword.isBlank()) {
            errors.add("Password confirmation is required.");
        } else if (!confirmPassword.equals(password)) {
            errors.add("Password confirmation does not match.");
        }

        return errors;
    }

    // metoda folosita pentru partea de update a datelor utilizatorului
    public static List<String> validateUserDetails(String firstName, String lastName, String username, String email) {
        List<String> errors = new ArrayList<>();

        if (firstName == null || firstName.isBlank()) {
            errors.add("First name is required.");
        }
        if (lastName == null || lastName.isBlank()) {
            errors.add("Last name is required.");
        }
        if (username == null || username.isBlank()) {
            errors.add("Username is required.");
        }
        if (email == null || email.isBlank()) {
            errors.add("Email is required.");
        } else if (!email.matches("^[a-zA-Z0-9](?!.*\\.\\.)[a-zA-Z0-9._-]*[a-zA-Z0-9]@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,6}$")) {
            errors.add("Invalid email format.");
        }

        return errors;
    }

    // metoda folosita pentru partea de update a datelor utilizatorului
    public static List<String> validateUserUpdate(String firstName, String lastName, String username, String email, String password, String confirmPassword, UserService userService, Integer currentUserId) {
        List<String> errors = validateUserDetails(firstName, lastName, username, email);

        // verificare pentru ca noul username sa nu existe deja in baza de date
        if(username != null && !username.isBlank() && userService.existsByUsername(username)) {
            User existingUser = userService.getUserByUsername(username);
            if(existingUser != null && !existingUser.getId_user().equals(currentUserId)) {
                errors.add("Username already exists!");
            }
        }
        // validare parola doar dacă este introdusa
        if (password != null && !password.isBlank()) {
            if (password.length() < 8) {
                errors.add("Password must be at least 8 characters long.");
            }
            if (!password.matches(".*[a-z].*")) {
                errors.add("Password must contain at least one lowercase letter.");
            }
            if (!password.matches(".*[A-Z].*")) {
                errors.add("Password must contain at least one uppercase letter.");
            }
            if (!password.matches(".*\\d.*")) {
                errors.add("Password must contain at least one number.");
            }
            if (!password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
                errors.add("Password must contain at least one special character.");
            }
            if (!password.equals(confirmPassword)) {
                errors.add("Password confirmation does not match.");
            }
        }

        return errors;
    }
}

