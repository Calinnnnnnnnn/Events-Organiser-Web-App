package com.events_organiser.manage_events.repository;


import com.events_organiser.manage_events.model.EventExtras;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EventExtrasRepository extends JpaRepository<EventExtras, Integer> {

}

