package com.events_organiser.manage_events.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    //ruta pentru index
    @GetMapping("/")
    public String index() {
        return "index";
    }

    //ruta pentru pagina de signup
    @GetMapping("/signup")
    public String signupPage() {
        return "signup";
    }
}
