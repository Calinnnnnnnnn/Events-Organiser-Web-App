package com.events_organiser.manage_events.controller;

import com.events_organiser.manage_events.model.LoginRequest;
import com.events_organiser.manage_events.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {

    @Autowired
    public UserService userService;

    //ruta pentru pagina de login
    @GetMapping("/login")
    public String showLoginPage(Model model){
        return "loginpage";
    }

    //autentificarea userului
    @PostMapping("/authenticate")
    public String authenticateUser(LoginRequest loginRequest, Model model, HttpSession session){
        //folosirea metodei din UserService pentru a compara datele introduse de
        //utilizator cu cele din baza de date
        boolean isAuthenticated = userService.authenticateUser(loginRequest.getUsername(), loginRequest.getPassword());
        if(isAuthenticated){
            session.setAttribute("authenticatedUser", loginRequest.getUsername());

            int loggedUserId = userService.getUserByUsername(loginRequest.getUsername()).getId_user();
            //setarea in sesiune a id-ului userului
            session.setAttribute("loggedUserId", loggedUserId);
            return "redirect:/dashboard";
        }

        //adaugarea erorilor in model daca este cazul
        model.addAttribute("error", "Invalid username or password!");
        return "loginpage";
    }

    //ruta pentru logout
    @GetMapping("/logout")
    public String logout(HttpSession session){
        session.invalidate();
        return "redirect:/login";
    }

}
