package com.events_organiser.manage_events.controller;

import com.events_organiser.manage_events.util.UserValidator;
import com.events_organiser.manage_events.model.User;
import com.events_organiser.manage_events.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import java.util.List;

@Controller
public class UserController {

    @Autowired
    public UserService userService;

    //ruta pentru pagina de signup
    @RequestMapping("/signup")
    public String signup(){
        return "signup";
    }

    @PostMapping("/signup")
    public String signupUser(@RequestParam("username") String username,
                             @RequestParam("email") String email,
                             @RequestParam("password") String password,
                             @RequestParam("confirmPassword") String confirmPassword,
                             @RequestParam("firstName") String firstName,
                             @RequestParam("lastName") String lastName,
                             Model model){

        //validarea datelor introduse de utilizator folosind UserValidator
        List<String> errors = UserValidator.validateUser(firstName, lastName, username, email, password, confirmPassword);

        //verificare daca username-ul exista deja in baza de date
        if(userService.existsByUsername(username)){
            errors.add("Username is already taken! Please choose another one.");
        }

        //verificare daca email-ul exista deja in baza de date
        if(userService.existsByEmail(email)){
            errors.add("Ann account with this email already exists! Please choose another one.");
        }

        //adaugarea erorilor
        if(!errors.isEmpty()){
            model.addAttribute("errors", errors);
            return "signup";
        }

        //salvarea userului in baza de date in cazul in care nu sunt erori
        User newUser = new User(firstName, lastName, username, email, password);
        userService.saveUser(newUser); //save user

        model.addAttribute("mssage", "User has been registered successfully!");
        return "loginpage";
    }
}
