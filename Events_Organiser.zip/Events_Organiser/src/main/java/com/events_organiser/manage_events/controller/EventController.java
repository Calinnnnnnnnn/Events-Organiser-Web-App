package com.events_organiser.manage_events.controller;

import com.events_organiser.manage_events.model.Event;
import com.events_organiser.manage_events.repository.EventRepository;
import com.events_organiser.manage_events.service.EventService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
public class EventController {
    private final EventService eventService;
    private final EventRepository eventRepository;

    public EventController(EventService eventService, EventRepository eventRepository) {
        this.eventService = eventService;
        this.eventRepository = eventRepository;
    }


    //extrage evenimentele pe baza id-ului de la user
    @GetMapping("/api/events")
    public List<Event> getEventsByUserId(@RequestParam Integer userId) {
        return eventService.getEventByUserId(userId);
    }

    //extrage urmatorul eveniment
    @GetMapping("/next/event")
    public Event getNextEvent(@RequestParam("userId") Integer userId) {
        return eventService.findNextEvent(userId);
    }

    //pagina pentru un nou eveniment
    @GetMapping("/new_event")
    public String newEventPage(){
        return "new_event";
    }

    //stergerea unui eveniment pe baza id-ului acestuia
    // din lista de evenimente ale unui user
    @GetMapping("/delete_event/{eventId}")
    public String confirmDelete(@PathVariable Integer eventId, Model model) {
        Optional<Event> event = eventRepository.findById(eventId);
        if(event.isPresent()) {
            model.addAttribute("event", event.get());
            return "confirm_delete";
        }
        return "redirect:/dashboard";
    }

    //confirmarea de stergere a evenimentului
    @PostMapping("/delete_event/{eventId}/confirm")
    public String deleteEvent(@PathVariable Integer eventId) {
        Optional<Event> event = eventRepository.findById(eventId);
        if(event.isPresent()) {
            eventRepository.deleteById(eventId);
            return "redirect:/dashboard";
        }
        return "redirect:/dashboard";
    }

    //Ruta pentru a vizaliza formularul de editare
    @GetMapping("/edit_event/{eventId}")
    public String showEditEventForm(@PathVariable("eventId") int eventId, Model model) {
        Event event = eventService.getEventById(eventId);
        model.addAttribute("event", event);
        return "edit_event";
    }

    //Ruta pentru procesarea formularului
    @PostMapping("/edit_event/{eventId}")
    public String updateEvent(@PathVariable("eventId") Integer eventId,
                              @RequestParam("eventName") String eventName,
                              @RequestParam("eventDescription") String eventDescription,
                              @RequestParam("eventType") String eventType,
                              @RequestParam("eventLocation") String eventLocation,
                              @RequestParam("eventDate") String eventDate,
                              Model model) {
        Event event = eventService.getEventById(eventId);

        //setarea datelor pentru un eveniment
        event.setEventName(eventName);
        event.setEventDescription(eventDescription);
        event.setEventType(eventType);
        event.setLocation(eventLocation);
        event.setEventDate(LocalDateTime.parse(eventDate));

        eventService.saveEvent(event);

        model.addAttribute("message", "Event has been updated successfully");
        return "redirect:/dashboard";
    }
}
