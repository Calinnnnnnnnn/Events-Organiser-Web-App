package com.events_organiser.manage_events.controller;

import com.events_organiser.manage_events.model.Event;
import com.events_organiser.manage_events.model.EventExtras;
import com.events_organiser.manage_events.model.User;
import com.events_organiser.manage_events.service.EventService;
import com.events_organiser.manage_events.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;

@Controller
public class NewEventController {

    private final EventService eventService;
    private final UserService userService;

    @Autowired
    public NewEventController(EventService eventService, UserService userService) {
        this.eventService = eventService;
        this.userService = userService;
    }

    //crearea unui nou eveniment
    @PostMapping("/create_event")
    public String createEvent(@RequestParam("event_name") String eventName,
                              @RequestParam("event_description") String eventDescription,
                              @RequestParam("event_type") String eventType,
                              @RequestParam("event_date") String eventDate,
                              @RequestParam("event_location") String eventLocation,
                              @RequestParam(value = "extra_speakers", defaultValue = "0") int speakers,
                              @RequestParam(value = "extra_drones", defaultValue = "0") int drones,
                              @RequestParam(value = "extra_lighting", defaultValue = "0") int lighting,
                              @RequestParam(value = "extra_catering", defaultValue = "0") int catering,
                              HttpSession session,
                              Model model) {
        Integer loggedUserId = (Integer) session.getAttribute("loggedUserId");

        //verifica daca utilizatorul este logat
        if(loggedUserId == null) {
            return "redirect:/login"; //redirectionare catre login daca nu este logat
        }

        StringBuilder errorMessage = new StringBuilder();

        //validari pentru campuri
        if(eventName == null || eventName.isBlank()) {
            errorMessage.append("Event name is required.\n" );
        }

        if(eventType == "Select event type" || eventType.isBlank()) {
            errorMessage.append("Event type is required.\n");
        }

        if(eventDate == null || eventDate.isBlank()) {
            errorMessage.append("Event date is required.\n");
        } else {
            try{
                //verificare daca data introdusa nu este in trecut
                LocalDateTime parseddate = LocalDateTime.parse(eventDate);
                if(parseddate.isBefore(LocalDateTime.now())) {
                    errorMessage.append("Event date is before current date. It must be in the future.\n");
                }
            } catch(Exception e){
                errorMessage.append("Invalid date format. Please use yyyy-MM-ddTHH:mm:ss.\n");
            }
        }

        if(eventLocation == null || eventLocation.isBlank()) {
            errorMessage.append("Event location is required\n");
        }

        if(errorMessage.length() > 0) {
            model.addAttribute("errorMessage", errorMessage.toString().replace("\n", "<br>"));
            model.addAttribute("eventName", eventName);
            model.addAttribute("eventDescription", eventDescription);
            model.addAttribute("eventType", eventType);
            model.addAttribute("eventDate", eventDate);
            model.addAttribute("eventLocation", eventLocation);
            model.addAttribute("extraSpeakers", speakers);
            model.addAttribute("extraDrones", drones);
            model.addAttribute("extraLighting", lighting);
            model.addAttribute("extraCatering", catering);
            return "new_event";
        }

        //setarea datelor in cazul in care nu exista erori
        Event event = new Event();
        event.setEventName(eventName);
        event.setEventDescription(eventDescription);
        event.setEventType(eventType);
        event.setEventDate(LocalDateTime.parse(eventDate));
        event.setLocation(eventLocation);
        event.setUserId(loggedUserId);

        // calculam costurile extra
        double totalCost = speakers * 50 + drones * 100 + lighting * 30 + catering * 200;

        // adaugam informațiile in model pentru pagina de plata
        model.addAttribute("event", event);
        model.addAttribute("extraSpeakers", speakers);
        model.addAttribute("extraDrones", drones);
        model.addAttribute("extraLighting", lighting);
        model.addAttribute("extraCatering", catering);
        model.addAttribute("totalCost", totalCost);

        // stocam evenimentul temporar in sesiune
        session.setAttribute("tempEvent", event);
        session.setAttribute("tempExtras", new int[]{speakers, drones, lighting, catering});

        return "payment_page";
    }

    //ruta pentru pagina de plata
    @PostMapping("/finalize_payment")
    public String finalizePayment(HttpSession session) {
        Event event = (Event) session.getAttribute("tempEvent");
        int[] extras = (int[]) session.getAttribute("tempExtras");

        if (event != null && extras != null) {
            // salvam evenimentul
            eventService.saveEvent(event);

            // salvam opțiunile extra
            if (extras[0] > 0) {
                EventExtras speakerExtra = new EventExtras();
                speakerExtra.setEventId(event.getIdEvent());
                speakerExtra.setExtraType("Speakers");
                speakerExtra.setQuantity(extras[0]);
                speakerExtra.setUnitPrice(50);
                eventService.saveEventExtras(speakerExtra);
            }

            if (extras[1] > 0) {
                EventExtras droneExtra = new EventExtras();
                droneExtra.setEventId(event.getIdEvent());
                droneExtra.setExtraType("Drones");
                droneExtra.setQuantity(extras[1]);
                droneExtra.setUnitPrice(100);
                eventService.saveEventExtras(droneExtra);
            }

            if (extras[2] > 0) {
                EventExtras lightingExtra = new EventExtras();
                lightingExtra.setEventId(event.getIdEvent());
                lightingExtra.setExtraType("Lighting");
                lightingExtra.setQuantity(extras[2]);
                lightingExtra.setUnitPrice(30);
                eventService.saveEventExtras(lightingExtra);
            }

            if (extras[3] > 0) {
                EventExtras cateringExtra = new EventExtras();
                cateringExtra.setEventId(event.getIdEvent());
                cateringExtra.setExtraType("Catering");
                cateringExtra.setQuantity(extras[3]);
                cateringExtra.setUnitPrice(200);
                eventService.saveEventExtras(cateringExtra);
            }

            // curatam sesiunile
            session.removeAttribute("tempExtras");
            session.removeAttribute("tempEvent");
        }
        return "redirect:/dashboard";
    }
}
