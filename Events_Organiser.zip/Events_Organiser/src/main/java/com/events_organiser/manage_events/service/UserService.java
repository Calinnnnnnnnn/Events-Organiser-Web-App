package com.events_organiser.manage_events.service;

import com.events_organiser.manage_events.model.User;
import com.events_organiser.manage_events.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // salvarea userilor in baza de date
    public User saveUser(User user){
        // criptarea parolelor inainte de salvare
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        // salvare dupa criptare
        return userRepository.save(user);
    }

    // cautarea unui user utilizand username-ul
    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }

    // cautarea unui user utilizand email-ul
    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }

    // metoda pentru a extrage userul curent utilizand username-ul
    public User getUserByUsername(String username) {
        userRepository.flush();
        Optional<User> userOpt = userRepository.findByUsername(username);
        if(userOpt.isPresent()){
            return userOpt.get();
        }
        throw new RuntimeException("User not found: " + username);
    }

    // autentificarea utilizatorului utilizand username si parola
    public boolean authenticateUser(String username, String password){
        Optional<User> userOpt = userRepository.findByUsername(username);
        if(userOpt.isPresent()){
            User user = userOpt.get();
            return passwordEncoder.matches(password, user.getPassword());
        }

        // returneaza fals daca username-ul sau parola sunt incorecte
        return false;
    }

    // gasirea userului pe baza id-ului
    public User findUserById(Integer id){
        return userRepository.findById(id).orElse(null);
    }

    // update pentru datele personale schimnbate de utilizator
    @Transactional
    public User updateUser(User user){
        User updatedUser = userRepository.save(user);
        userRepository.flush();
        return updatedUser;
    }

    // criptare de parola
    public String encodePassword(String password){
        return passwordEncoder.encode(password);
    }
}
