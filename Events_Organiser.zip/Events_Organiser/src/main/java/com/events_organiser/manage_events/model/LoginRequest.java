package com.events_organiser.manage_events.model;

public class LoginRequest {

    private String username;
    private String password;

    //preluarea de date si setarea lor despre user
    //getters si setters
    //username
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    //password
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
}
