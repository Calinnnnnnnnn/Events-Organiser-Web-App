package com.events_organiser.manage_events;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventsOrganiserApplication {

    public static void main(String[] args) {

        SpringApplication.run(EventsOrganiserApplication.class, args);
    }

}
