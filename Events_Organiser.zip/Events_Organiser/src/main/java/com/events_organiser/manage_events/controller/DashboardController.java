package com.events_organiser.manage_events.controller;


import com.events_organiser.manage_events.model.Event;
import com.events_organiser.manage_events.model.User;
import com.events_organiser.manage_events.service.EventService;
import com.events_organiser.manage_events.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class DashboardController {

    private final UserService userService;
    private final EventService eventService;

    @Autowired
    public DashboardController(UserService userService, EventService eventService) {
        this.userService = userService;
        this.eventService = eventService;
    }

    @GetMapping("/dashboard")
    public String showDashboard(Model model, HttpSession session) {
        // Verifica dacă utilizatorul este autentificat
        String username = (String) session.getAttribute("authenticatedUser");
        if (username == null) {
            return "redirect:/login"; // dacă nu e autentificat, redirecționează către login
        }

        // Obține detaliile utilizatorului pe baza username-ului
        User currentUser = userService.getUserByUsername(username);
        if(currentUser == null) {
            return "redirect:/login";
        }
        //Lista de evenimente ale utilizatorului
        List<Event> events = eventService.getEventByUserId(currentUser.getId_user());
        Event nextEvent = eventService.findNextEvent(currentUser.getId_user());

        // Adaugă datele utilizatorului si evenimentele în model
        model.addAttribute("firstName", currentUser.getFirstName());
        model.addAttribute("userName", currentUser.getUsername());
        model.addAttribute("events", events);
        model.addAttribute("nextEvent", nextEvent);


        return "dashboard"; // redirecționează către pagina dashboard
    }
}
